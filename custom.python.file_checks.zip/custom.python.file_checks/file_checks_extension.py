from datetime import datetime
import logging
from pathlib import Path

from ruxit.api.base_plugin import BasePlugin
from ruxit.api.selectors import HostSelector

log = logging.getLogger(__name__)


class FileChecks(BasePlugin):
    def initialize(self, **kwargs):
        self.executions = 0

    def query(self, **kwargs) -> None:
        paths_size = [path for path in self.config.get("paths_size").split("\n") if path]
        paths_modified = [path for path in self.config.get("paths_modified").split("\n") if path]
        paths_exist = [path for path in self.config.get("paths_exist").split("\n") if path]
        paths_count = [path for path in self.config.get("paths_count").split("\n") if path]

        paths_count_types = self.config.get("paths_count_types")
        count_folders = paths_count_types in ("ALL", "FOLDERS")
        count_files = paths_count_types in ("ALL", "FILES")

        frequency = self.config.get("frequency", 1)
        if self.executions % frequency == 0:
            self.logger.info(f"Running the file checks")
            for path in paths_size:
                if not Path(path).exists():
                    self.results_builder.report_error_event(
                        f"Path '{path}' does not exist or cannot be read. Size cannot be calculated",
                        f"Path '{path}' does not exist"[:100],
                    )
                else:
                    self.results_builder.absolute(
                        key="path_size", value=size(path), dimensions={"Path": path}, entity_selector=HostSelector()
                    )

            for path in paths_modified:
                if not Path(path).exists():
                    self.results_builder.report_error_event(
                        f"Path '{path}' does not exist or cannot be read. Modified date cannot be calculated",
                        f"Path '{path}' does not exist"[:100],
                    )
                else:
                    self.results_builder.absolute(
                        key="paths_modified", value=last_modified(path), dimensions={"Path": path}, entity_selector=HostSelector()
                    )

            for path in paths_exist:
                self.results_builder.absolute(
                    key="paths_exist", value=exists(path), dimensions={"Path": path}, entity_selector=HostSelector()
                )

            for path in paths_count:
                if not Path(path).exists():
                    self.results_builder.report_error_event(
                        f"Path '{path}' does not exist or cannot be read. Count cannot be calculated",
                        f"Path '{path}' does not exist"[:100],
                    )
                else:
                    self.results_builder.absolute(
                        key="paths_count",
                        value=count(path, count_files, count_folders),
                        dimensions={"Path": path},
                        entity_selector=HostSelector(),
                    )
        else:
            self.logger.info(f"Not running. {frequency - (self.executions % frequency)} minutes remaining for next run")

        self.executions += 1


def size(path: str) -> int:
    sum_sizes = 0
    for f in Path(path).glob("**/*"):
        try:
            if f.is_file():
                sum_sizes += f.stat().st_size
        except Exception as e:
            log.error(f"Could not get size for {f}: {e}")
    return sum_sizes


def last_modified(path: str) -> float:
    return (datetime.now() - datetime.fromtimestamp(Path(path).stat().st_mtime)).total_seconds()


def exists(path: str) -> bool:
    return Path(path).exists()


def last_modified_window(path: str, window: int) -> bool:
    return last_modified(path) < window


def count(path: str, count_files: bool = True, count_folders: bool = True) -> int:
    return len([f for f in Path(path).glob("**/*") if (count_files and f.is_file()) or (count_folders and f.is_dir())])


def main():
    print(size("/tmp"))
    print(last_modified("/tmp/pip"))
    print(last_modified_window("/tmp/pip", 60))
    print(exists("/tmp/pip"))
    print(count("/tmp", count_files=False))


if __name__ == "__main__":
    main()
